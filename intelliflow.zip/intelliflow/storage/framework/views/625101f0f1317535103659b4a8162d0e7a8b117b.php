<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Intellflow</title>
        <!-- <script>
            addEventListener("load", function () {
                setTimeout(hideURLbar, 0);
            }, false);

            function hideURLbar() {
                window.scrollTo(0, 1);
            }
        </script> -->

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

        <!-- Styles -->
        <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </head>
    <body>
       <div class="banner container">
            <div class="header_nav row pt-4">
                <div class="col-sm-12 text-right pr-5">
                    <a href="#">
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                    
                </div>
                <div class="col-sm-4">
                    <img src="<?php echo e(asset('frontend/images/Banner/IF_logo.svg')); ?>" class="img-fluid" alt="logo">
                </div>
                <div class="col-sm-8">
                    <nav class="navbar navbar-expand-sm" >
                        <ul class="navbar-nav ml-auto">
                          <li class="nav-item active">
                            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#features">Features</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#about">About</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#how_it_works">How it works</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#blogs">Blogs</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#contact">Contact us</a>
                          </li>
                        </ul>
                    </nav>
                </div>

                <div class="row my-5">

                    <div class="col-sm-4 pt-5">
                      <h5 class="font-weight-bold mb-0">NEXT GENERATION</h5>
                      <h2 class="font-weight-bold">DevOps solution</h2>
                      <p>IntelliFlow is enabling IT teams to manage Continuous Integration, Deployment, Testing and Automated Defect
                        Management from a single platform…</p>
                      <a href="#" class="btn btn-outline-warning font-weight-bold" style="border-radius: 45px; border: 2px solid #EFC61A; color: #000">Explore More</a>
                    </div>
                  
                    <div class="col-sm-8 pt-5 pl-5 text-center">
                        <img src="<?php echo e(asset('frontend/images/Banner/banner_image.jpg')); ?>" class="img-fluid" alt="logo">
                    </div>
                </div>
            </div>        
       </div>
       <div class="features py-5 container-fluid" id="features">
            <div class="row pt-5 justify-content-center" >
                <div class="col-sm-6">
                 <h2>FEATURES</h2>
                 <p >IntelliFlow is an enterprise grade application development platform which can enable IT teams of various
                 technology stacks and sizes become DevOps mature with minimal upfront cost. At a high level, IntelliFlow
                 provides below main capabilities from a single platform as a service</p>

                 <img src="<?php echo e(asset('frontend/images/Features/arrows.svg')); ?>" class="img-fluid" alt="logo">
                </div>
            </div>  
        </div>

        <div class="works container-fluid" id="works">
            <div class="row justify-content-center py-5">
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/build_automation_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Build Automation
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/deployment_automation_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Deployment Automation
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/test_automation_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Test Automation
                    </a>
                 
                </div>
            </div>  
            <div class="row justify-content-center py-5">
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/UI_based_workflow_icon.svg')); ?>" class="img-fluid" alt="logo"><br>UI Based Workflow
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/intelligent_defect_management_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Intelligent Defect Management
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/easy_step_icon.svg')); ?>" class="img-fluid" alt="logo"><br>EASY SETUP
                    </a>
                 
                </div>   
            </div>    
        </div>

        <div class="about container-fluid" id="about">
             <div class="row mt-5 justify-content-center">

                    <div class="col-sm-4 pt-5 mr-5">
                      <h2>About</h2>
                      <p>IntelliFlow is next generation AI powered DevOps solution enabling IT teams to manage Continuous Integration, Deployment, Testing and Automated Defect Management from a single platform. We have abstracted complexities involved in integrating disjoint toolsets behind a simple intuitive UI. IntelliFlow can be deployed as a service or on premise depending upon the client requirements.
                      </p>
                      <p>
                       With an easy setup and ability to manage the pipeline at project level, we empower our customers to configure the Build, Deployment and Testing logic from UI as per their requirements. Our AI powered automated defect management solution removes the manual process of raising defects and provides actionable insights for defect triage and resolution. We provide out of the box integrations with Slack and Jira and support testing tools such as Selenium and JMeter. We have flexible deployment options for IntelliFlow which suits IT teams of all sizes and complexity.
                       </p>
                      <p>
                        IntelliFlow is developed by product engineering team of Thinqe Technology Solutions (www.thinqe.com). Thinqe is a Sydney based technology company specializing in DevOps, Cloud Computing, Test Automation and AI. To know more about how IntelliFlow can assist your software development automation, please get in touch with us at contact@thinqe.com</p>
                    
                    </div>
                  
                    <div class="blog col-sm-4 pt-5 ml-5">
                      <h2>Blogs</h2>
                      <div class="blog py-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more..</a>
                      </div>
                      <div class="blog pb-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more..</a>
                      </div>
                      <div class="blog pb-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more..</a>
                      </div>
                      <div class="blog pb-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more..</a>
                      </div>
                    
                    </div>
                </div>
            
        </div>

        <div class="how_it_works container-fluid justify-content-center" id="how_it_works">
            <div class="row justify-content-center">
                <div class="col-sm-12 mt-5">
                    <h2 style="color: #EFC61D">How it works</h2>
                </div>
                <div class="slider col-sm-8 mb-5">
                    <div id="slider" class="carousel slide" data-ride="carousel">

                      <ol class="carousel-indicators">
                        <li data-target="#slider" data-slide-to="0" class="active"></li>
                        <li data-target="#slider" data-slide-to="1"></li>
                      </ol>
                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img class="d-block w-100" src="<?php echo e(asset('frontend/images/inteliflow-01.png')); ?>" alt="First slide">
                          <div class="carousel-caption d-none d-md-block">
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100 my-5" src="<?php echo e(asset('frontend/images/IF Driven Development Illustration.jpg')); ?>" alt="Second slide">
                        </div>
                      </div>
                    </div>
                    
                </div>
            </div>

           
            
        </div>
      
        <div class="get_intelliFlow container-fluid justify-content-center py-5" id="get">

            <h2 class="text-center">Get IntelliFlow</h2>

            <div class="row justify-content-center py-5 ">
                <div class="get_me col-sm-2 mr-5" >
                   <h3 class="pt-5 text-center">Community</h3>
                   <ul class="mt-5">
                       <li>1 Project </li>
                        <li> 3 Users </li>
                        <li>  Cloud Hosted </li>
                        <li> Limited Integrations </li>
                        <li> Limited Support Upgrades</li>
                   </ul>
                 <h5 class="pt-5 text-center">Free</h5>
                 <div class="text-center">
                     <button  class="btn btn-outline-warning" id="getBtn" style="border: 2px solid #000000; color: #000000">GET</button>
                 </div>
                 
                </div>
                <div class="get_me col-sm-2 mr-5" style="color: #fff; background-color: #313133">
                    <h3 class="pt-5 text-center">Standard</h3>
                        
                   <ul class="mt-5">
                       <li> 3 Projects </li>
                        <li> 10 Users per Project </li>
                        <li>  Cloud Hosted </li>
                        <li> Standard Integrations </li>
                        <li> Standard Support Upgrades</li>
                   </ul>
                 <h5 class="pt-2 text-center" style="color: #EFC61A">$10K AUD PER YEAR</h5>
                 <div class="text-center">
                     <button  class="btn btn-outline-warning" id="getBtn" >GET</button>
                 </div>
                 
                </div>
                <div class="get_me col-sm-2 " style="color: #fff; background-color: #000000">

                    <h3 class="pt-5 text-center">pro</h3>
                   <ul class="mt-5">
                       <li>Unlimited Projects </li>
                        <li> Unlimited Users </li>
                        <li>  On Prem or Cloud </li>
                        <li> Custom and Standard Integrations </li>
                        <li>  Premium support & upgrades</li>
                   </ul>
                 <h5 class=" text-center" style="color: #EFC61A">Request a quote</h5>
                 <div class="text-center">
                     <button  class="btn btn-outline-warning" id="getBtn" >GET</button>
                 </div>
                 
                </div>
            </div>            
        </div>

         <div class="container-fluid">
             <div class="row mt-5 justify-content-center" id="contact">

                    <div class="col-sm-4 pt-5 mr-5">
                      <h2>Contact Us</h2>
                      <p>L24, 3 International Towers, Barangaroo, NSW, 2000, Australia </p>
                      <p>Email: contact@intelliflow.io</p>
                      
                      <iframe
                        src="https://maps.google.com/maps?q=fatmonk&t=&z=15&ie=UTF8&iwloc=&output=embed">
                            
                        </iframe>

                    
                    </div>
                  
                    <div class="blog col-sm-2 pt-5 ml-5">
                      <h2>For Enquiries</h2>
                      <form action="#" method="post">
                        <label>FULL NAME *</label>
                        <input type="text"  class="form-control mb-3" placeholder="Full Name">
                        <label>YOUR EMAIL *</label>
                        <input type="email"  class="form-control  mb-3" placeholder="E-mail">
                        <label>CONTACT NUMBER</label>
                        <input type="text"  class="form-control  mb-3" placeholder="Contact Number">
                        <div class="form-group pt-4">
                            <textarea class="form-control" rows="3" placeholder="Message"></textarea>
                        </div>
                        <button class="btn btn-warning font-weight-bold" id="getBtn" style=" border: 2px solid #EFC61A; color: #000" type="submit">Submit</button>

                </form>
                    
                    </div>
                </div>
            
        </div> 

      
<footer>
  <div class="container-fluid mt-5">
    <div class="row">
      <div class="col-sm-12 mt-5 pt-4 text-center">
        <img src="<?php echo e(asset('frontend/images/Banner/IF_logo.svg')); ?>" class="img-fluid" alt="logo">
      </div>

      <div class=" foot_nav col-sm-12 mt-5">
        <nav class="navbar py-0 navbar-expand-sm py-md-0 justify-content-center" >
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#how_it_works">How will it work</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#get">Get IntelliFlow</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact us</a>
              </li>
            </ul>
        </nav>
      </div>
    

  </div>
  
  </div>

        <div class="foot_social container-fluid mt-5">
            <div class="row">
             
                <div class=" col-sm-12 text-center">
                     <a href="#">
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                </div>

            </div>
            
        </div>
        <div class="text-center mt-5">
            <p style="font-size: .7rem">&copy; IntelliFlow 2019</p>
        </div>

</footer>

    </body>
</html>
<?php /**PATH G:\office work\IntleFlow\intleflow\resources\views/welcome.blade.php ENDPATH**/ ?>