<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Intellflow</title>
        <!-- <script>
            addEventListener("load", function () {
                setTimeout(hideURLbar, 0);
            }, false);

            function hideURLbar() {
                window.scrollTo(0, 1);
            }
        </script> -->

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Staatliches&display=swap&subset=latin-ext" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,600,700&display=swap" rel="stylesheet">

        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

        <!-- Styles -->
        <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </head>
    <body>
       <div class="container pb-5" id="banner">
            <div class="row py-4">
                <div class="head_social col-sm-12 text-right pr-5">
                    <a href="#">
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                    
                </div>
                <div class="col-sm-4 pb-5">
                    <img src="<?php echo e(asset('frontend/images/Banner/IF_logo.svg')); ?>" class="img-fluid" alt="logo">
                </div>
                <div class="col-sm-8 pb-5">
                <!--Navbar -->
                
                    <nav class="navbar navbar-expand-lg navbar-light">
                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                      </button>

                      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                          <li class="nav-item">
                          <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#features">Features</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#about">About</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#how_it_works">How it works</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#blogs">Blogs</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#contact">Contact us</a>
                        </li>

                        </ul>
                        
                      </div>
                    </nav>

            <!--/.Navbar -->
                </div>

                <div class="col-sm-5 pl-5 py-5">
                  <h5 class="mb-0" style="font-size: 2.125rem">NEXT GENERATION</h5>
                  <h2>DevOps solution</h2>
                  <p style="font-size: 1rem; font-weight: 600">IntelliFlow is enabling IT teams to manage Continuous Integration, Deployment, Testing and Automated Defect
                    Management from a single platform…</p>
                  <a href="#" class="btn btn-outline-warning pl-4 pr-4 py-2" id="explore_btn">Explore More</a>
                </div>
              
                <div class="col-sm-7 py-5 pl-5 text-center">
                    <img src="<?php echo e(asset('frontend/images/Banner/banner_image.jpg')); ?>" class="img-fluid" alt="logo">
                </div>
            </div>        
       </div>
       <div class="features py-5 container-fluid" id="features">
            <div class="row pt-5 justify-content-center" >
                <div class="col-sm-6">
                 <h2>FEATURES</h2>
                 <p >IntelliFlow is an enterprise grade application development platform which can enable IT teams of various
                 technology stacks and sizes become DevOps mature with minimal upfront cost. At a high level, IntelliFlow
                 provides below main capabilities from a single platform as a service</p>

                 <img src="<?php echo e(asset('frontend/images/Features/arrows.svg')); ?>" class="img-fluid" alt="logo">
                </div>
            </div>  
        </div>

        <div class="works container-fluid py-5 my-5" id="works">
            <div class="row justify-content-center py-5">
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/build_automation_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Build Automation
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/deployment_automation_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Deployment Automation
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/test_automation_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Test Automation
                    </a>
                 
                </div>
            </div>  
            <div class="row justify-content-center py-5">
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/UI_based_workflow_icon.svg')); ?>" class="img-fluid" alt="logo"><br>UI Based Workflow
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/intelligent_defect_management_icon.svg')); ?>" class="img-fluid" alt="logo"><br>Intelligent Defect <br>Management
                    </a>
                 
                </div>
                <div class="col-sm-3 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/Features/easy_step_icon.svg')); ?>" class="img-fluid" alt="logo"><br>EASY SETUP
                    </a>
                 
                </div>   
            </div>    
        </div>

        <div class="about container-fluid py-5" id="about">
             <div class="row mt-5 justify-content-center">

                    <div class="col-sm-4 pt-5 mr-5">
                      <h2>About</h2>
                      <p>IntelliFlow is next generation AI powered DevOps solution enabling IT teams to manage Continuous Integration, Deployment, Testing and Automated Defect Management from a single platform. We have abstracted complexities involved in integrating disjoint toolsets behind a simple intuitive UI. IntelliFlow can be deployed as a service or on premise depending upon the client requirements.
                      </p>
                      <p>
                       With an easy setup and ability to manage the pipeline at project level, we empower our customers to configure the Build, Deployment and Testing logic from UI as per their requirements. Our AI powered automated defect management solution removes the manual process of raising defects and provides actionable insights for defect triage and resolution. We provide out of the box integrations with Slack and Jira and support testing tools such as Selenium and JMeter. We have flexible deployment options for IntelliFlow which suits IT teams of all sizes and complexity.
                       </p>
                      <p>
                        IntelliFlow is developed by product engineering team of Thinqe Technology Solutions (www.thinqe.com). Thinqe is a Sydney based technology company specializing in DevOps, Cloud Computing, Test Automation and AI. To know more about how IntelliFlow can assist your software development automation, please get in touch with us at contact@thinqe.com</p>
                    
                    </div>
                  
                    <div class="blog col-sm-3 pt-5 ml-5" id="blogs">
                      <h2>Blogs</h2>
                      <div class="blog py-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more</a>
                      <hr style="border: 1px solid #E0E0E0;">
                      </div>
                      <div class="blog pb-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more</a>
                      <hr style="border: 1px solid #E0E0E0;">
                      </div>
                      <div class="blog pb-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more</a>
                      <hr style="border: 1px solid #E0E0E0;">
                      </div>
                      <div class="blog pb-5">
                          <h5>Excepteur sint.</h5>
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <a href="">Read more</a>
                      <hr style="border: 1px solid #E0E0E0;">
                      </div>
                    
                    </div>
                </div>
            
        </div>

        <div class="how_it_works container-fluid justify-content-center py-5" id="how_it_works">
            <div class="row justify-content-center">
                <div class="col-sm-12 mt-5">
                    <h2 style="color: #EFC61D">How it works</h2>
                </div>
                <div class="slider col-sm-10">
                    <div id="slider" class="carousel slide" data-ride="carousel">

                      <div class="carousel-inner">
                        <div class="carousel-item active">
                          <img class="d-block w-100" src="<?php echo e(asset('frontend/images/inteliflow-01.png')); ?>" alt="First slide">
                          <div class="carousel-caption d-none d-md-block">
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="<?php echo e(asset('frontend/images/inteliflow-2-01.png')); ?>" alt="Second slide">
                        </div>
                      </div>
                        <a class="carousel-control-prev" href="#slider" role="button" data-slide="prev">
                            <span class="fa fa-angle-left" aria-hidden="true" style="font-size: 50px;"></span>
                            <span class="sr-only">Previous</span>
                          </a>
                          <a class="carousel-control-next" href="#slider" role="button" data-slide="next">
                              
                            <span class="fa fa-angle-right" aria-hidden="true" style="font-size: 50px;"></span>
                            <span class="sr-only">Next</span>
                          </a>
                    </div>
                    
                </div>
            </div>
       
        </div>

      
        <div class="get_intelliFlow container-fluid justify-content-center py-5" id="get">

            <h2 class="text-center py-5">Get IntelliFlow</h2>

            <div class="row justify-content-center py-5 ">
                <div class="col-pixel-width-100" >
                    <div class="get_me pt-4">
                        <h3 class="pt-5 text-center">Community</h3>
                       <ul class="mt-4">
                           <li>&nbsp;  1 Project </li>
                            <li>&nbsp; 3 Users </li>
                            <li>&nbsp;  Cloud Hosted </li>
                            <li>&nbsp; Limited Integrations </li>
                            <li>&nbsp; Limited Support</li>
                            <li>&nbsp; Upgrades</li>
                       </ul>
                     
                     <div class="btn_pos text-center">
                     
                        <h5 class="text-center">Free</h5>
                        <br>
                         <button  class="btn btn-outline-warning pl-5 pr-5" id="getBtn" style="border: 3px solid #000000; color: #000000">GET</button>
                     </div>
                    </div>
                   
                 
                </div>
                <div class=" col-pixel-width-100" >
                    <div class="get_me pt-4" style="color: #fff; background-color: #313133">
                        <h3 class="pt-5 text-center" style="color: #EFC61A;">Standard</h3>
                        
                       <ul class="mt-4">
                            <li>&nbsp; 3 Projects </li>
                            <li>&nbsp; 10 Users per Project </li>
                            <li>&nbsp;  Cloud Hosted </li>
                            <li>&nbsp; Standard Integrations </li>
                            <li>&nbsp; Standard Support Upgrades</li>
                            
                       </ul>
                    

                     <div class="btn_pos text-center">
                        <h5 class="text-center" style="color: #EFC61A">$10K AUD</h5>
                        <h6 class="text-center" style="color: #FFFFFF">PER YEAR</h6>
                         <button  class="btn btn-outline-warning pl-5 pr-5" id="getBtn" >GET</button>
                     </div>
                 
                    </div>
                    
                </div>
                <div class=" col-pixel-width-100" >
                    <div class="get_me pt-4" style="color: #fff; background-color: #000000">
                        <h3 class="pt-5 text-center" style="color: #EFC61A;">pro</h3>
                       <ul class="mt-4">
                           <li>&nbsp; Unlimited Users </li>
                           <li>&nbsp; Unlimited Projects </li>
                            <li>&nbsp;  On Prem or Cloud </li>
                            <li>&nbsp; Custom and Standard Integrations </li>
                            <li>&nbsp;  Premium support & upgrades</li>
                       </ul>
                     
                     <div class="btn_pos text-center">
                        <h5 class=" text-center" style="color: #EFC61A">Request a quote</h5>
                       <br>
                         <button  class="btn btn-outline-warning text-center pl-5 pr-5" id="getBtn" >GET</button>
                     </div>
                    </div> 
                </div>
            </div>            
        </div>

         <div class="container-fluid py-5">
             <div class="contact row py-5 justify-content-center" id="contact">

                    <div class="col-sm-4 pt-5 mr-5">
                      <h1 class="pb-4">Contact Us</h1>
                      <p>L24, 3 International Towers,<br> Barangaroo, NSW, 2000,<br> Australia </p>
                      <p>Email:<br> contact@intelliflow.io</p>
                      
                      <iframe
                         src="https://maps.google.com/maps?q=L24%2C%203%20International%20Towers%2C%20Barangaroo%2C%20NSW%2C%202000%2C%20Australia&t=&z=13&ie=UTF8&iwloc=&output=embed">
                            
                        </iframe>

                    
                    </div>
                  
                    <div class="cont_form col-sm-3 pt-5 ml-5">
                      <h3 style="color: #EFC61A">For Enquiries</h3>
                      <p>We will call you as soon as<br> possible to discuss your needs,</p>
                      <form action="#" method="post">
                        <label>FULL NAME *</label>
                        <input type="text"  class="form-control mb-3" placeholder="John ABC">
                        <label>YOUR EMAIL *</label>
                        <input type="email"  class="form-control  mb-3" placeholder="test@mail.com">
                        <label>CONTACT NUMBER</label>
                        <input type="text"  class="form-control  mb-3" placeholder="0123 123 456">
                        <div class="form-group pt-4 ">
                            <textarea class="form-control" rows="3" placeholder="Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore"></textarea>
                            <p class="text-center" id="label">ADD COMMENT</p>
                        </div>
                        <button class="btn btn-warning" id="submitBtn"type="submit">Submit</button>

                </form>
                    
                    </div>
                </div>
            
        </div> 

      
<footer>
  <div class="container-fluid mt-5">
    <!-- move top icon -->
                    
                    <!-- //move top icon -->

    <div class="row">
      <div class="col-sm-2 move-top mt-3">
          <a href="#banner">
            <span class="fa fa-arrow-up" aria-hidden="true"></span>
          </a>
      </div>
      <div class="col-sm-12 pt-4 text-center mb-5">
        <img src="<?php echo e(asset('frontend/images/Banner/IF_logo.svg')); ?>" class="img-fluid" alt="logo">
      </div>

      <div class=" foot_nav col-sm-12">
        <!--Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light py-0 my-0">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
              <li class="nav-item">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#how_it_works">How it works</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#get">Get IntelliFlow</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="#contact">Contact us</a>
            </li>

            </ul>
            
          </div>
        </nav>
      </div>
    

  </div>
  
  </div>

        <div class="foot_social container-fluid mt-5">
            <div class="row">
             
                <div class=" col-sm-12 text-center">
                     <a href="#">
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                </div>

            </div>
            
        </div>
        <div class="text-center mt-5">
            <p style="font-size: .7rem">&copy; IntelliFlow 2019</p>
        </div>

</footer>
  
    </body>
</html>
<?php /**PATH C:\Users\User\Desktop\intelliflow\resources\views/welcome.blade.php ENDPATH**/ ?>